package kr.ac.konkuk.tab;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import com.amitshekhar.DebugDB;
import com.google.android.material.tabs.TabLayout;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import androidx.fragment.app.FragmentManager;


public class MainActivity extends AppCompatActivity{

    public static Context mContext;
    private ViewPager vp;
    private VPAdapter adapter;
    dbHelper dbhelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext=this;

        vp =findViewById(R.id.viewpager);
        adapter =new VPAdapter(getSupportFragmentManager());
        vp.setAdapter(adapter);

        //연동
        TabLayout tab=findViewById(R.id.tab);
        tab.setupWithViewPager(vp);
        vp.setCurrentItem(0);

        //db연동
        dbhelper=new dbHelper(this);
        try {
            db = dbhelper.getWritableDatabase();
        } catch (SQLiteException ex) {
            db = dbhelper.getReadableDatabase();
        }

    }

    public void replaceFragment() {
        vp.setCurrentItem(1);
    }

    public void insert(String mmtabataname, String str_Tabatatype, ArrayList<String> strList, int set, int exercisetime, int resttime, int settime) { //
        String tabataname= mmtabataname;
        String mstr_Tabatatype = str_Tabatatype;
        int mset=set;
        ArrayList<String> mstrList=strList;
        int mexercisetime=exercisetime;
        int mresttime=resttime;
        int msettime=settime;
        String mmstrList="";

        for(int j=0;j<mstrList.size();j++){
            mmstrList = mmstrList+mstrList.get(j)+"///";
        }

        ContentValues contentValues =new ContentValues();
        contentValues.put("mtabataname",tabataname);
        contentValues.put("tabatatype",mstr_Tabatatype);
        contentValues.put("sets",mset);
        contentValues.put("strList",mmstrList); //
        contentValues.put("exercisetime",mexercisetime);
        contentValues.put("resttime",mresttime);
        contentValues.put("settime",msettime);

        db.insert("contact",null,contentValues);

        Toast.makeText(getApplicationContext(), "성공적으로 추가되었음", Toast.LENGTH_SHORT).show();

    }

    public ArrayList<MainData> firstdbsetting(){
        Cursor cursor =db.rawQuery("SELECT * FROM contact", null);
        ArrayList<MainData> firstarrayList =new ArrayList<>();

       while(cursor.moveToNext()){
            String a= cursor.getString(3);
            ArrayList<String> exercisearray=new ArrayList<String>();
            String[] splitText = a.split("///");
            for(int i=0;i<splitText.length;i++){
                exercisearray.add(splitText[i]);
                System.out.println(String.valueOf(i)+splitText[i]);
            }
            MainData maindata = new MainData(cursor.getString(0),cursor.getString(1),cursor.getInt(2),exercisearray,cursor.getInt(4),cursor.getInt(5),cursor.getInt(6));
            firstarrayList.add(maindata);
        }
       return firstarrayList;
    }

    void delete(String name) {
        int result = db.delete("contact", "mtabataname=?", new String[] {name});

    }






}