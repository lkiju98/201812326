package kr.ac.konkuk.tab;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import org.w3c.dom.Text;

import java.util.ArrayList;

import static kr.ac.konkuk.tab.VPAdapter.items;

public class MainAdaptor extends RecyclerView.Adapter<MainAdaptor.CustomViewHolder> {

    public static ArrayList<MainData> arrayList;
    public MainAdaptor(ArrayList<MainData> arrayList) {
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MainAdaptor.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
        CustomViewHolder holder = new CustomViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MainAdaptor.CustomViewHolder holder, int position) {
        holder.tabataname.setText(arrayList.get(position).getTabataname());
        holder.item_name.setText(arrayList.get(position).getItem_name());
        holder.item_sets.setText(arrayList.get(position).get_set());

        holder.itemView.setTag(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //item 눌렀을때

                ((MainActivity)MainActivity.mContext).replaceFragment();

                Bundle bundle = new Bundle();
                bundle.putInt("index", holder.getAdapterPosition());

                Fragment2.newInstance(bundle);

            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) { //item 길게 눌렀을때

//                Toast.makeText(v.getContext(),curName,Toast.LENGTH_SHORT).show();

                remove(holder.getAdapterPosition());

                String curName= holder.tabataname.getText().toString();

                ((MainActivity)MainActivity.mContext).delete(curName);
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return (null != arrayList? arrayList.size():0);
    }

    public void remove(int position){
        try{
            arrayList.remove(position);
            notifyItemRemoved(position);
        } catch(IndexOutOfBoundsException ex){
            ex.printStackTrace();
        }
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        protected TextView tabataname;
        protected TextView item_name;
        protected TextView item_sets;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tabataname=(TextView)itemView.findViewById(R.id.tabataname);
            this.item_name=(TextView)itemView.findViewById(R.id.item_name);
            this.item_sets=(TextView)itemView.findViewById(R.id.item_sets);
                    }
    }

}
