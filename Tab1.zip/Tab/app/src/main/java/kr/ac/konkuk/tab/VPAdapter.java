package kr.ac.konkuk.tab;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class VPAdapter extends FragmentPagerAdapter {

    public static ArrayList<Fragment> items;
    private ArrayList<String> itext=new ArrayList<String>();

    public VPAdapter(FragmentManager fm) {
        super(fm);
        items=new ArrayList<Fragment>();
        items.add(new Fragment1());
        items.add(new Fragment2());
        items.add(new Fragment3());

        itext.add("Setting");
        itext.add("Workout");
        itext.add("Record");
    }

    @NonNull
    @Override
    public CharSequence getPageTitle (int position) {
        return itext.get(position);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return items.get(position);
    }

//    public Fragment getItem(int position) {
//        switch (position) {
//            case 0:
//                return Fragment1.newInstance(0, "Page # 1");
//            case 1:
//                return Fragment2.newInstance(1, "Page # 2");
//            case 2:
//                return Fragment3.newInstance(2, "Page # 3");
//            default:
//                return null;
//        }
//    }
//

    @Override
    public int getCount() {
        return items.size();
    }
}
