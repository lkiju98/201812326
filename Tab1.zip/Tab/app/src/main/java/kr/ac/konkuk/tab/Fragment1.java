package kr.ac.konkuk.tab;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.annotation.Target;
import java.util.ArrayList;

import static android.provider.Telephony.Mms.Part.FILENAME;

public class Fragment1 extends Fragment {

    public Fragment1() {
        // Required empty public constructor
    }

    Dialog dialog; //새로만든 커스텀 Dialog

    private ArrayList<MainData> arrayList;
    private MainAdaptor mainAdaptor;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview1 = (ViewGroup)inflater.inflate (R.layout.fragment_1,container,false);

        recyclerView= (RecyclerView) rootview1.findViewById(R.id.rv);
        linearLayoutManager=new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        arrayList=new ArrayList<>();


        mainAdaptor=new MainAdaptor(arrayList);
        recyclerView.setAdapter(mainAdaptor);

        Button btn_add=(Button)rootview1.findViewById(R.id.btn_add);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickAdd();
            }
        });
        return rootview1;
    }


    public void ClickAdd (){
        final Dialog dialog= new Dialog(getActivity()); //dialog 만들기

        dialog.setContentView(R.layout.custom_setting); //custom_dialog.xml 불러오기
        final Button pre = (Button) dialog.findViewById(R.id.SettingPre); //확인버튼 가져오기 (pbutton)
        final Button next = (Button) dialog.findViewById(R.id.SettingNext); //취소버튼 가져오기 (nbutton)
        final EditText types = (EditText) dialog.findViewById(R.id.types);
        final RadioGroup rg= (RadioGroup) dialog.findViewById(R.id.radioGroup);

        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
        dialog.show(); //dialog 창띄우기

        //pre 버튼
        pre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                dialog.dismiss(); //버튼 누르면 dialog창 끄기
                //String value=et.getText().toString(); //edittext에 있는 값을 string으로 value변수에 저장하기
                //btnSelectNum.setText(value); //activity_main.xml의 test에 btnSelectNum에 value값을 넣어주기
            }
        });

        // next 버튼
        next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                final Dialog dialog2 = new Dialog(getActivity()); //dialog 만들기
                dialog2.setContentView(R.layout.setting2);

                final LinearLayout exercisell= dialog2.findViewById(R.id.exercisell);
                final ArrayList<String> strList = new ArrayList<String>();
                int num=1;
                if (types.getText().toString().equals("") || types.getText().toString() == null){ }
                    else{num = Integer.parseInt(types.getText().toString());}
                for (int i=0;i<num;i++) {
                    EditText et = new EditText(getActivity().getApplicationContext());
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    et.setLayoutParams(p);
                    et.setHintTextColor(Color.parseColor("#495057"));
                    et.setTextColor(Color.parseColor("#ffffff"));
                    et.setHint("Exercise Name"+(i+1)+"의 이름");
                    et.setId(num);
                    exercisell.addView(et);
                }

                WindowManager.LayoutParams params = dialog2.getWindow().getAttributes();
                params.width = WindowManager.LayoutParams.MATCH_PARENT;
                params.height = WindowManager.LayoutParams.MATCH_PARENT;
                dialog2.getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
                dialog2.show();

                final Button pre = (Button) dialog2.findViewById(R.id.SettingPre2); //확인버튼 가져오기 (pbutton)
                final Button next = (Button) dialog2.findViewById(R.id.SettingNext2); //취소버튼 가져오기 (nbutton)

                pre.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog2.dismiss();
                    }
                });

                next.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //타바타 종류
                        RadioButton rd = (RadioButton) dialog.findViewById(rg.getCheckedRadioButtonId());
                        String str_Tabatatype = rd.getText().toString();

                        //타바타운동이름들
                        int num=1;
                        if (types.getText().toString().equals("") || types.getText().toString() == null){ }
                        else{num = Integer.parseInt(types.getText().toString());}

                        for (int i=0;i<num;i++) {
                            EditText et = (EditText) exercisell.getChildAt(i);
                            if (et.getText().toString().equals("") || et.getText().toString() == null){
                                String a=Integer.toString(i+1);
                                strList.add("exercise"+a); }
                            else{strList.add(et.getText().toString());}
                        }

                        //세트수
                        final EditText sets=(EditText)dialog.findViewById(R.id.sets);
                        int set = 3;
                        if (sets.getText().toString().equals("") || sets.getText().toString() == null){ }
                        else{set = Integer.parseInt(sets.getText().toString());}


                        //시간관련값
                        final EditText exercisetimes=(EditText)dialog2.findViewById(R.id.exercisetimes);
                        int exercisetime = 10;
                        if (exercisetimes.getText().toString().equals("") || exercisetimes.getText().toString() == null){ }
                        else{exercisetime = Integer.parseInt(exercisetimes.getText().toString());}

                        final EditText resttimes=(EditText)dialog2.findViewById(R.id.resttimes);
                        int resttime = 3;
                        if (resttimes.getText().toString().equals("") || resttimes.getText().toString() == null){ }
                        else{resttime = Integer.parseInt(resttimes.getText().toString());}

                        final EditText settimes=(EditText)dialog2.findViewById(R.id.settimes);
                        int settime = 5;
                        if (settimes.getText().toString().equals("") || settimes.getText().toString() == null){ }
                        else{settime = Integer.parseInt(settimes.getText().toString());}

                        dialog.dismiss();
                        dialog2.dismiss();



                        MainData mainData= new MainData(R.drawable.ic_launcher_background,str_Tabatatype,set,strList,exercisetime,resttime,settime);

                        arrayList.add(mainData);
                        mainAdaptor.notifyDataSetChanged();
                    }
                });


            }
        });
    }


}