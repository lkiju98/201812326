package kr.ac.konkuk.tab;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import static android.view.animation.Animation.RELATIVE_TO_SELF;
import static kr.ac.konkuk.tab.MainAdaptor.arrayList;
import static kr.ac.konkuk.tab.VPAdapter.items;

public class Fragment2 extends Fragment {


    int myProgress = 0;
    ProgressBar progressBarView;
    public static Button btn_start;
    TextView tv_time;
    TextView current_set;
    TextView current_workout;
    int progress;
    int flag=1;
    CountDownTimer countDownTimer;
    int endTime = 250;

    public static void newInstance(Bundle bundle) {
        int index = bundle.getInt("index", 0);
        System.out.println("ㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎ");
        System.out.println(String.valueOf(index));

        Fragment fragment = VPAdapter.items.get(1);
        fragment.setArguments(bundle);
        btn_start.setText("Start Timer");
    }



    public Fragment2() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootview2 = (ViewGroup)inflater.inflate (R.layout.fragment_2,container,false);

        progressBarView = (ProgressBar) rootview2.findViewById(R.id.view_progress_bar);
        btn_start = (Button)rootview2.findViewById(R.id.btn_start);
        tv_time= (TextView)rootview2.findViewById(R.id.tv_timer);
        current_set= (TextView)rootview2.findViewById(R.id.current_set);
        current_workout= (TextView)rootview2.findViewById(R.id.current_workout);

        /*Animation*/
        RotateAnimation makeVertical = new RotateAnimation(0, -90, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
        makeVertical.setFillAfter(true);
        progressBarView.startAnimation(makeVertical);
        progressBarView.setSecondaryProgress(endTime);
        progressBarView.setProgress(0);

        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag=flag*-1;
                if(flag==-1){//시작
                    btn_start.setText("QUIT");
                    fn_countdown();
                }else{//멈추기
                    btn_start.setText("Reset & ReStart");
                    countDownTimer.cancel();
                }
            }
        });
        return rootview2;
    }


    public ArrayList<String> timeroutine=new ArrayList();
    public ArrayList<String> exerciseroutine=new ArrayList();
    int j;


    private void fn_countdown() {

        int index = getArguments().getInt("index", 0);

        MainData mainData= arrayList.get(index);

        String set= mainData.get_set();
        String item=mainData.getItem_name();

        ArrayList<String> exercise= mainData.getIt_strList();
        int exercise_size=exercise.size();
        String exercisetime=mainData.get_exercisetime();
        String resttime=mainData.get_resttime();
        String settime=mainData.get_settime();

        System.out.println(set);
        System.out.println(item); //방식
        System.out.println(exercisetime);
        System.out.println(resttime);
        System.out.println(settime);
        System.out.println(exercise.get(0));



        if(item=="AAA/BBB/CCC..."){
//            for(int k=0;k<exercise_size;k++) {
//
//                for (int q = 0; q < Integer.parseInt(set); q++) {
//                    timeroutine.add(exercisetime);
//                    timeroutine.add(resttime);
//                }
//                timeroutine.add(settime);
//            }

        }else{
            for(int k=0;k<exercise_size;k++) {

                for (int q = 0; q < Integer.parseInt(set); q++) {
                    exerciseroutine.add(exercise.get(k));
                    timeroutine.add(exercisetime);
                    exerciseroutine.add("rest");
                    timeroutine.add(resttime);
                }
                timeroutine.add(settime);
                exerciseroutine.add("set breaktime");
            }

        }
        clock(Integer.parseInt(timeroutine.get(0)),exerciseroutine.get(0));

    }

    public interface MyEventListener {
        void onEvent();
    }
    MyEventListener listener = new MyEventListener() {
        @Override
        public void onEvent() {
            if(j<timeroutine.size()){
                clock(Integer.parseInt(timeroutine.get(j)),exerciseroutine.get(j));
            }
        }
    };






    private int clock(int time, String current) {
            //오류잡기
            try {
                countDownTimer.cancel();
            } catch (Exception e) {
            }

            progress = 1;
            endTime = time; // up to finish time

            System.out.println(endTime);
            //System.out.println(current);
            current_workout.setText(current);

            countDownTimer = new CountDownTimer(endTime * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    setProgress(progress, endTime);
                    progress = progress + 1;
                    int seconds = (int) (millisUntilFinished / 1000) % 60;
                    tv_time.setText(String.valueOf(seconds));
//                    int minutes = (int) ((millisUntilFinished / (1000 * 60)) % 60);
//                    String newtime =minutes + ":" + seconds;
//                    if (newtime.equals("0:0")) {
//                        tv_time.setText("00:00");
//                    } else if ((String.valueOf(minutes).length() == 1) && (String.valueOf(seconds).length() == 1)) {
//                        tv_time.setText("0" + minutes + ":0" + seconds);
//                    } else if ((String.valueOf(minutes).length() == 1)) {
//                        tv_time.setText("0" + minutes + ":" + seconds);
//                    } else if ((String.valueOf(seconds).length() == 1)) {
//                        tv_time.setText(minutes + ":0" + seconds);
//                    } else {
//                        tv_time.setText(minutes + ":" + seconds);
//                    }
                }

                @Override
                public void onFinish() {
                    setProgress(progress, endTime);
                    j=j+1;
                    listener.onEvent();
                }
            };
            countDownTimer.start();
            return 0;
    }

    public void setProgress(int startTime, int endTime) {
        progressBarView.setMax(endTime);
        progressBarView.setSecondaryProgress(endTime);
        progressBarView.setProgress(startTime);


    }
}