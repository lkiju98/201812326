package kr.ac.konkuk.tab;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity{

    public static Context mContext;
    private ViewPager vp;
    private VPAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext=this;

        vp =findViewById(R.id.viewpager);
        adapter =new VPAdapter(getSupportFragmentManager());
        vp.setAdapter(adapter);

        //연동
        TabLayout tab=findViewById(R.id.tab);
        tab.setupWithViewPager(vp);
        vp.setCurrentItem(0);

    }

    public void replaceFragment() {
        vp.setCurrentItem(1);
    }




}